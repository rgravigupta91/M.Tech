# Project1 > 2025-01-25 11:34am
https://universe.roboflow.com/computervision-39ovo/project1-3o5o2

Provided by a Roboflow user
License: CC BY 4.0

