# -*- coding: utf-8 -*-
"""
Created on Sat Sep 25 09:09:05 2021

@author: Senthil
"""


#https://drive.google.com/file/d/1tJsW4h55sxqhZ_x61_f7MAXitFNnuRGJ/view?usp=sharing

from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input,Conv2D,Dense,Dropout,MaxPooling2D,GlobalAveragePooling2D

def build_siamese_model(inputShape,embeddingDim=10):
    inputs=Input(inputShape)
    x=Conv2D(64,(3,3),padding='same',activation='relu')(inputs)
    x=MaxPooling2D(pool_size=(2,2))(x)
    x=Dropout(0.2)(x)
    
    x=Conv2D(64,(3,3),padding='same',activation='relu')(x)
    x=MaxPooling2D(pool_size=(2,2))(x)
    x=Dropout(0.2)(x)
    
    pooledOutput=GlobalAveragePooling2D()(x)
    outputs=Dense(embeddingDim)(pooledOutput)
    
    model=Model(inputs,outputs)
    
    return model