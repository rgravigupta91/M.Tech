# -*- coding: utf-8 -*-
"""
Created on Sat Sep 25 11:22:27 2021

@author: Senthil
"""

from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input,Conv2D,Dense,Dropout,MaxPooling2D,GlobalAveragePooling2D,Lambda
from siamese_base_model import build_siamese_model
import utils
from tensorflow.keras.datasets import mnist
import numpy as np
from matplotlib import pyplot as plt


(trainX,trainY),(testX,testY)=mnist.load_data()
trainX=trainX/255.0
testX=testX/255.0

trainX=np.expand_dims(trainX,axis=3)
testX=np.expand_dims(testX,axis=3)

(pairTrain,labelTrain)=utils.make_pairs(trainX,trainY)
(pairTest,labelTest)=utils.make_pairs(testX,testY)

i=1
plt.figure(1),plt.imshow(pairTrain[i,0,:,:,0])
plt.figure(2),plt.imshow(pairTrain[i,1,:,:,0])
print('The target is:',labelTrain[i])

imgA=Input(shape=(28,28,1))
imgB=Input(shape=(28,28,1))

featureExtractor=build_siamese_model((28,28,1))
featA=featureExtractor(imgA)
featB=featureExtractor(imgB)

distance=Lambda(utils.euclidean_distance)([featA,featB])
outputs=Dense(1,activation='sigmoid')(distance)

model=Model(inputs=[imgA,imgB],outputs=outputs)

model.compile(loss='binary_crossentropy',optimizer='adam',metrics=['accuracy'])

model.fit(
        [pairTrain[:,0,:,:,:],pairTrain[:,1,:,:,:]],
        labelTrain,
        validation_data=([pairTest[:,0,:,:,:],pairTest[:,1,:,:,:]],labelTest),
        batch_size=128,
        epochs=5)


