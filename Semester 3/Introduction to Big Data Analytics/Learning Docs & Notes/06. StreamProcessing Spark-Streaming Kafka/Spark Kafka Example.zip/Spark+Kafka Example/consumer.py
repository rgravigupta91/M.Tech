from pyspark.sql import SparkSession
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils


spark = SparkSession.builder.appName('appname').getOrCreate()

sc = spark.sparkContext

ssc = StreamingContext(sc, 10)

kvs = KafkaUtils.createDirectStream(ssc,topics=["kafkatest"],kafkaParams={"metadata.broker.list":"localhost:9092"})

lines = kvs.map(lambda x : x[1])

counts = lines.flatMap(lambda line: line.split(" ")).map(lambda word : (word, 1)).reduceByKey(lambda a,b: a+b)

counts.pprint()

ssc.start()
ssc.awaitTermination()

ssc.stop()

