from kafka import KafkaProducer
import json
import os

bootstrap = 'localhost: 9092'

producer = KafkaProducer(bootstrap_servers = bootstrap)

json_producer = KafkaProducer(bootstrap_servers = bootstrap, value_serializer = lambda v: json.dumps(v).encode('utf-8'))

topic_name = 'kafkatest'
#producer.send(topic_name, "Hello there how are you")

#producer.send(topic_name, "Hello Hello Hello")

for i in range(100):
    json_producer.send(topic_name, value="Hello there how are you")
    producer.flush()
