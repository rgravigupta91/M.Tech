#Structured Streaming Example

import findspark
findspark.init()
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

#create sparksession
spark = SparkSession.builder.appName("StructStream").getOrCreate()


#creating Schema
#structured Streaming proccesing always requires the specification of a schema for the data in the stream
schema = StructType([StructField('emp_id', IntegerType(), True),
                   StructField('emp_name', StringType(), True),
                   StructField('job_name', StringType(), True),
                   StructField('manager_id', IntegerType(), True),
                   StructField('salary', DoubleType(), True),
                   StructField('dept_name', StringType(), True)])


#creating Streaming Dataframe that would read the data from a given folder
customer = spark.readStream.schema(schema)\
			.option("header", True)\
			.option("sep", ",")\
			.csv("C:/Users/Documents/streamingdatafolder")


#query to find the total count of employees in a particular profession
customer.groupBy("job_name").count().writeStream.format('console').outputMode('complete').start().awaitTermination()

